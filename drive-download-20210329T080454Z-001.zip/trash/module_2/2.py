import os
import sys

path = os.getcwd()
print(path)
# parpath=os.path.abspath(os.path.join(path, os.pardir))
# sys.path.append(parpath)


print(sys.path)
# import .module_1
